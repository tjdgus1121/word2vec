# Word2Vec 모델 파일 위치

이 폴더에 `word2vec_ko.json` 파일을 넣어주세요.

## 파일 요구사항

- **파일명**: `word2vec_ko.json`
- **형식**: JSON
- **구조**: 
```json
{
  "단어1": [0.123, -0.456, 0.789, ...],  // 300차원 벡터
  "단어2": [0.234, -0.567, 0.890, ...],
  ...
}
```

## 파일 준비 방법

### 옵션 1: 기존 파일 복사
이미 `word2vec_ko.json` 파일이 있다면 이 폴더에 복사하세요.

```bash
cp /path/to/word2vec_ko.json ./
```

### 옵션 2: FastText 모델 변환
FastText 모델이 있다면 JSON으로 변환할 수 있습니다.

### 옵션 3: 다운로드
외부 링크에서 다운로드 받으세요.

## 파일 크기 권장사항

- **최소**: 10MB (약 3,000 단어) - 기본 게임용
- **권장**: 20-50MB (약 10,000~15,000 단어) - 최적
- **최대**: 100MB (GitHub 제한)

## 배포 후 CDN URL

파일을 추가하고 GitHub에 push하면:
```
https://cdn.jsdelivr.net/gh/사용자명/word2vec-game@main/data/word2vec_ko.json
```

이 URL을 `index.html` 39번째 줄에 설정하세요.
