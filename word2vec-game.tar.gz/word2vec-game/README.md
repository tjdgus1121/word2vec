# Word2Vec 코사인 유사도 끝말잇기

실제 Word2Vec 모델을 사용한 의미 유사도 기반 끝말잇기 게임입니다.

## 🚀 빠른 시작

### 1단계: word2vec_ko.json 준비
`data/` 폴더에 `word2vec_ko.json` 파일을 복사하세요.

### 2단계: GitHub Repository 생성
https://github.com/new 에서 새 repository를 만드세요.
- Repository name: `word2vec-game` (또는 원하는 이름)
- Public 선택

### 3단계: index.html 수정
39번째 줄의 CDN URL을 수정하세요:
```javascript
const CDN_URL = 'https://cdn.jsdelivr.net/gh/YOUR_USERNAME/word2vec-game@main/data/word2vec_ko.json';
```
→ `YOUR_USERNAME`을 실제 GitHub 사용자명으로 변경

### 4단계: Git Push
```bash
cd word2vec-game

# Git 초기화 (처음 한 번만)
git init
git branch -M main

# 사용자 정보 설정
git config user.email "your@email.com"
git config user.name "Your Name"

# Commit & Push
git add .
git commit -m "Initial commit: Word2Vec game"
git remote add origin https://github.com/YOUR_USERNAME/word2vec-game.git
git push -u origin main
```

### 5단계: GitHub Pages 활성화
1. Repository → Settings → Pages
2. Source: `main` branch 선택
3. Save 클릭

5분 후 다음 URL에서 접속 가능:
```
https://YOUR_USERNAME.github.io/word2vec-game/
```

## 📊 게임 규칙

- **제한 시간**: 60초
- **유사도 기준**: 70점 이상 (코사인 유사도 0.70)
- **끝말잇기 규칙**: 이전 단어의 마지막 글자로 시작
- **중복 불가**: 이미 사용한 단어 재사용 불가
- **콤보 보너스**: 연속 성공 시 +5점씩 추가

## 🎯 기술 스택

### Word2Vec
- **차원**: 300차원 벡터
- **학습 데이터**: 한국어 위키백과 + 나무위키
- **어휘 수**: 약 50,000 단어

### 코사인 유사도
```
cos(θ) = (A·B) / (||A|| × ||B||)
```

### CDN 및 캐싱
- **jsDelivr**: GitHub 파일을 전세계 CDN으로 배포
- **Service Worker**: 브라우저 캐싱으로 재방문 시 즉시 로딩

## 📁 파일 구조

```
word2vec-game/
├── index.html          # 메인 게임 파일
├── sw.js              # Service Worker
├── README.md          # 이 파일
├── .gitignore
└── data/
    ├── word2vec_ko.json   # Word2Vec 모델 (여기에 파일 추가!)
    └── README.md
```

## 🔧 로컬 테스트

```bash
# Python 3
python -m http.server 8000

# Node.js
npx http-server

# 브라우저에서
http://localhost:8000
```

## 📈 성능 최적화

- **첫 방문**: 50MB 다운로드 (jsDelivr CDN)
- **재방문**: 0MB (Service Worker 캐시)
- **GitHub Pages 트래픽**: ~5KB (HTML만)

## 🛠️ 문제 해결

### Push 실패 시
```bash
# 버퍼 증가
git config http.postBuffer 524288000
git push
```

### CDN 캐시 갱신
```
https://purge.jsdelivr.net/gh/YOUR_USERNAME/word2vec-game@main/data/word2vec_ko.json
```

### Service Worker 초기화
브라우저 개발자 도구(F12) 콘솔:
```javascript
caches.keys().then(keys => keys.forEach(key => caches.delete(key)));
```

## 📝 라이선스

MIT License

---

**Made with ❤️ for AI Education**
